The code should be compiled as .cpp or it will go wrong!
Just use your terminal and input 
     gcc code.cpp
and you will get the executable file.
Tips:the encoding is GB2312, not utf-8!
