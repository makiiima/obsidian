You can paste my code to [PAT (Advanced Level) Practice 1163 Dijkstra Sequence](https://pintia.cn/problem-sets/994805342720868352/exam/problems/1478635670373253120?type=7&page=1). It's accepted.
Or you can compile it by yourself and test in native environment.
