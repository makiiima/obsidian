import os, argparse
import torch
import json
import numpy as np
import torch.nn as nn
import torch.optim as optim

from model import base_model
from train.train_baseline import run_train
from utilities import config, utils, dataset as data
from utilities.utils import seed_torch,saved_for_eval


def train():
    seed_torch(0)
    os.environ["CUDA_VISIBLE_DEVICES"] = '0'
    output_path = 'saved_models/{}/{}'.format(config.type + config.version, 'baseline')
    utils.create_dir(output_path)
    torch.backends.cudnn.benchmark = True
    

    # load training dataset and validation dataset
    train_loader = data.get_loader('train')
    val_loader = data.get_loader('val')

    # initialize model
    embeddings = np.load(os.path.join(config.cache_root, 'glove6b_init_300d.npy'))
    constructor = 'build_%s' % 'baseline'
    model = getattr(base_model, constructor)(embeddings, val_loader.dataset.num_ans_candidates).cuda()
    # set cuda
    model = nn.DataParallel(model).cuda()
    # initialize optimizer
    optimizer = optim.Adamax(model.parameters())

    r = np.zeros(3)
    start_epoch = 0
    acc_val_best = 0
    tracker = utils.Tracker()
    model_path = os.path.join(output_path, 'model.pth')

    # train 
    for epoch in range(start_epoch, config.epochs):
        run_train(model, train_loader, optimizer, tracker, prefix='train', epoch=epoch)
        if not (config.mode == 'trainval' and epoch in range(config.epochs - 5)):
            r = run_test(model, val_loader, optimizer, tracker, prefix='val', epoch=epoch)

        results = {
            'epoch': epoch,
            'acc_val_best': acc_val_best,
            'model_state': model.state_dict(),
            'optim_state': optimizer.state_dict(),
        }
        if config.mode == 'train' and r[1].mean() > acc_val_best:
            acc_val_best = r[1].mean()
            saved_for_eval(val_loader, r, output_path, epoch)
        if config.mode == 'trainval' and epoch in range(config.epochs - 5, config.epochs):
            saved_for_eval(val_loader, r, output_path, epoch)
        torch.save(results, model_path)

if __name__ == '__main__':
    train()