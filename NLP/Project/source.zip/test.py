import os, argparse
import torch
import json
import numpy as np
import torch.nn as nn
import torch.optim as optim

from model import base_model
from train.train_baseline import run_test
from utilities import config, utils, dataset as data
from utilities.utils import seed_torch,saved_for_eval


def test():
    # args = parse_args()
    seed_torch(0)
    os.environ["CUDA_VISIBLE_DEVICES"] = '0'
    output_path = 'saved_models/{}/{}'.format(config.type + config.version, "baseline")
    utils.create_dir(output_path)
    torch.backends.cudnn.benchmark = True

    # get test dataset
    train_loader = None
    val_loader = data.get_loader('val')

    # initialize model
    embeddings = np.load(os.path.join(config.cache_root, 'glove6b_init_300d.npy'))
    constructor = 'build_%s' % 'baseline'
    model = getattr(base_model, constructor)(embeddings, val_loader.dataset.num_ans_candidates).cuda()
    model = nn.DataParallel(model).cuda()
    optimizer = optim.Adamax(model.parameters())

    r = np.zeros(3)
    start_epoch = 0
    acc_val_best = 0
    tracker = utils.Tracker()
    model_path = os.path.join(output_path, 'model.pth')
    # load model
    logs = torch.load(model_path)
    start_epoch = logs['epoch']
    acc_val_best = logs['acc_val_best']
    model.load_state_dict(logs['model_state'])
    optimizer.load_state_dict(logs['optim_state'])

    # model test
    r = run_test(model, val_loader, optimizer, tracker, prefix='test', epoch=epoch)
    saved_for_eval(val_loader, r, output_path, epoch)

if __name__ == '__main__':
    test()