# Process data
python tools/compute_softscore.py
python tools/create_dictionary.py