[![DOI](https://zenodo.org/badge/627544269.svg)](https://zenodo.org/badge/latestdoi/627544269)

# Orient
Repository for "Enc2:Privacy-Preserving Inference for Tiny IoTs via Encoding and Encryption" paper. 

## Dependencies:
This code was tested on g++ 14.0 and python 3.8. 

## Building:
Scripts are provided in script folder to build and run the code. We used g++ for building all the c/c++ files. 
