#!/usr/bin/env bash

# Prepare
cd ../code/

g++ *.cpp -o orient